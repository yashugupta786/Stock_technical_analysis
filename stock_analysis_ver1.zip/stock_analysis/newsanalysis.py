from GoogleNews import GoogleNews
from boilerpy3 import extractors
googlenews = GoogleNews(lang='en')
googlenews.get_news('tata steel')
news_url=googlenews.get_links()[0]
import requests
r= requests.get("https://"+news_url)
news_url=str(r.url)
extractor = extractors.ArticleExtractor()
def body_extract(url):
    doc = extractor.get_doc_from_url(url)
    content = doc.content
    return content

body_text=body_extract(news_url)
print(body_text)
data_final=body_text.split("\n")
