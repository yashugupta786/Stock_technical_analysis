import pandas_datareader.data as web
import datetime
import pandas as pd
import math
start = datetime.datetime(2020, 12, 1)
end = datetime.datetime.now()
df=pd.read_csv("ind_nifty200list.csv")
# df=pd.read_excel("demo.xlsx")
# company_name=[]
# company_symbol=[]
# closing_price=[]
# range_value=[]
# sma_price=[]
# Industry=[]
# skipped_company=[]
# skipped_symbol=[]
# skipped_price=[]
# skipped_value=[]
# candle_type=[]
# daily_trend=[]
# weekly_trend=[]
# close_candle_intersection=[]
# volume_curr=[]
# volume_prev=[]

company_name, company_symbol, closing_price, Industry,sma_price,skipped_company,skipped_symbol ,skipped_price= ([] for i in range(8))
skipped_value, candle_type, daily_trend, weekly_trend,close_candle_intersection,volume_curr,volume_prev,range_value,skip_candle_type= ([] for j in range(9))
def dow(dayNumber):
    days=["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
    value=days[dayNumber]
    return value

def get_week_candle(week_df):
    close_data=week_df["Close"][-1]
    date_extract = week_df.index[0]._date_repr
    low_value = week_df["Low"].min()
    open_val=week_df["Open"][0]
    return close_data,date_extract,low_value,open_val

def millify(n):
    millnames = ['', ' Thousand', ' Million', ' Billion', ' Trillion']
    n = float(n)
    millidx = max(0,min(len(millnames)-1,
                        int(math.floor(0 if n == 0 else math.log10(abs(n))/3))))
    return '{:.0f}{}'.format(n / 10**(3 * millidx), millnames[millidx])


for i, row in df.iterrows():
    symbol=row["Symbol"]
    print("starring---->",symbol)
    try:
        df1 = web.DataReader([symbol+'.NS'], 'yahoo', start=start, end=end)[["Close","Low","Open","Volume"]]
        df1.columns = ['Close',"Low","Open","Volume"]
        df1['Weekday'] = df1.index.get_level_values(0).weekday
        df1['week_number'] = df1.index.get_level_values(0).week
        df1["DayName"]=df1["Weekday"].apply(dow)
        df1["44_SMA"] = df1["Close"].rolling(window=44, min_periods=1).mean()
        df1["Volume_conv"]=df1["Volume"].apply(millify)
        final_value=round(df1["Close"][-1] - df1["44_SMA"][-1], 2)
        if round(final_value)<=20 and  round(final_value)>=-5 and df1["Close"][-1]>=30:
            print("Processing------>", row["Company Name"])
            if df1["Close"][-1]> df1["Open"][-1]:
                candle_type.append("green candle")
            else:
                candle_type.append("Red Candle")
            exact_touch_point=df1["Low"][-1]-df1["44_SMA"][-1]
            if round(exact_touch_point,2)>=0 and round(exact_touch_point,2)<=3:
                close_candle_intersection.append(round(exact_touch_point,2))
            elif round(exact_touch_point, 2) >= -3 and round(exact_touch_point, 2) <= 0:
                close_candle_intersection.append(round(exact_touch_point, 2))
            else:
                close_candle_intersection.append("No Range")
#-------------------ROAD UNDER CONSTRUCTION--------------------Asuvidha ke liye khed hai--------------
            weekly_analysis_df=pd.DataFrame(columns=["Date","close_data","low_value","open_data","week_number"])
            gp_data=df1.groupby("week_number",sort = False)
            for name in gp_data.groups:
                group = gp_data.get_group(name)
                close_data,date_extract,low_value,open_val = get_week_candle(group)
                df2 = pd.DataFrame({"Date": [date_extract],
                                    "close_data": [close_data],
                                    "low_value": [low_value],
                                    "open_data": [open_val],
                                    "week_number": [name],
                                    })
                weekly_analysis_df= weekly_analysis_df.append(df2, ignore_index=True)
                df2 = pd.DataFrame(None)

            half_val=int(len(weekly_analysis_df["close_data"])/2)
            if round(weekly_analysis_df["close_data"],2).tolist()[-1] > round(weekly_analysis_df["close_data"][0],2) and round(weekly_analysis_df["close_data"],2).tolist()[-1]>round(weekly_analysis_df["close_data"][half_val],2):
                weekly_trend.append("Bullish")
            else:
                weekly_trend.append("Bearish")
            daily_half=half_val=int(len(df1["Close"])/2)
            if round(df1["Close"][-1],2) > round(df1["Close"][0],2) and round(df1["Close"][-1],2) > round(df1["Close"][daily_half],2) :
                daily_trend.append("Strongly Bullish")
            elif round(df1["Close"][-1],2) > round(df1["Close"][0],2) :
                if round(df1["Close"][-1],2) < round(df1["Close"][daily_half],2):
                    daily_trend.append("partially Bullish")
            else:
                daily_trend.append("Bearish")

#-------------New Analysis ----Code under Construction
            company_name.append(row["Company Name"])
            company_symbol.append(row["Symbol"])
            Industry.append(row["Industry"])
            closing_price.append(round(df1["Close"][-1]))
            sma_price.append(round(df1["44_SMA"][-1]))
            range_value.append(final_value)
            volume_curr.append(df1["Volume_conv"][-1])
            volume_prev.append(df1["Volume_conv"][-2])
        else:
            if df1["Close"][-1] > df1["Open"][-1]:
                skip_candle_type.append("green candle")
            else:
                skip_candle_type.append("Red Candle")
            print("skipping+++",row["Company Name"])
            skipped_company.append(row["Company Name"])
            skipped_symbol.append(row["Symbol"])
            skipped_price.append(round(df1["Close"],2))
            skipped_value.append(final_value)
    except Exception as e:
        print("In Exception")
        pass

df2=pd.DataFrame()
df2["Company Name"]=company_name
df2["Symbol"]=company_symbol
df2["Industry"]=Industry
df2["Closing price"]=closing_price
df2["SMA Value"]=sma_price
df2["MA close to Candle (-3 to 3)"]=close_candle_intersection
df2["Daily Trend"]=daily_trend
df2["weekly Trend"]=weekly_trend
df2["candle Type"]=candle_type
df2["Today's Volume"]=volume_curr
df2["Yesterday Volume"]=volume_prev
df2["Range"]=range_value


df3=pd.DataFrame()
df3["company skipped"]=skipped_company
df3["skipped symbol"]=skipped_symbol
df3["skipped prices"]=skipped_price
df3["difference values"]=skipped_value
df3["Candle_type"]=skip_candle_type

df2.to_excel("E:\codes_segregation\stock_analysis\stock_data\shortlisted_stock4.xlsx",index=False)
df3.to_excel("E:\codes_segregation\stock_analysis\stock_data\skipped_stock4.xlsx",index=False)


